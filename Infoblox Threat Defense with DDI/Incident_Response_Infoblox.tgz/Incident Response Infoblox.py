"""
Automate SOC response with enrichment, priority updates, and SNOW ticket creation.
"""


import phantom.rules as phantom
import json
from datetime import datetime, timedelta


@phantom.playbook_block()
def on_start(container):
    phantom.debug('on_start() called')

    # call 'fetch_insight_indicators' block
    fetch_insight_indicators(container=container)

    return

@phantom.playbook_block()
def fetch_insight_assets(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("fetch_insight_assets() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Get asset data linked with Insight.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.Insight ID","artifact:*.id"])

    parameters = []

    # build parameters list for 'fetch_insight_assets' call
    for container_artifact_item in container_artifact_data:
        if container_artifact_item[0] is not None:
            parameters.append({
                "limit": 100,
                "insight_id": container_artifact_item[0],
                "context": {'artifact_id': container_artifact_item[1]},
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("get iq for td insights assets", parameters=parameters, name="fetch_insight_assets", assets=["test_infoblox"], callback=fetch_insight_details)

    return


@phantom.playbook_block()
def fetch_insight_events(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("fetch_insight_events() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Get related security events for Insight.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.Insight ID","artifact:*.id"])

    parameters = []

    # build parameters list for 'fetch_insight_events' call
    for container_artifact_item in container_artifact_data:
        if container_artifact_item[0] is not None:
            parameters.append({
                "limit": 100,
                "insight_id": container_artifact_item[0],
                "threat_level": "All",
                "threat_confidence": "All",
                "context": {'artifact_id': container_artifact_item[1]},
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("get iq for td insights events", parameters=parameters, name="fetch_insight_events", assets=["test_infoblox"], callback=fetch_insight_assets)

    return


@phantom.playbook_block()
def check_suspicious_events(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("check_suspicious_events() called")

    ################################################################################
    # Evaluate Insight threat level.
    ################################################################################

    # check for 'if' condition 1
    found_match_1 = phantom.decision(
        container=container,
        logical_operator="or",
        conditions=[
            ["fetch_insight_events:action_result.data.*.events.*.threat_level", "==", "High"],
            ["fetch_insight_events:action_result.data.*.events.*.threat_level", "==", "Medium"]
        ],
        conditions_dps=[
            ["fetch_insight_events:action_result.data.*.events.*.threat_level", "==", "High"],
            ["fetch_insight_events:action_result.data.*.events.*.threat_level", "==", "Medium"]
        ],
        name="check_suspicious_events:condition_1",
        delimiter=None)

    # call connected blocks if condition 1 matched
    if found_match_1:
        set_priority_to_high(action=action, success=success, container=container, results=results, handle=handle)
        return

    # check for 'else' condition 2
    set_priority_to_low(action=action, success=success, container=container, results=results, handle=handle)

    return


@phantom.playbook_block()
def set_priority_to_high(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("set_priority_to_high() called")

    ################################################################################
    # Change event priority to High.
    ################################################################################

    id_value = container.get("id", None)

    parameters = []

    parameters.append({
        "name": None,
        "tags": None,
        "label": None,
        "owner": None,
        "status": None,
        "severity": "high",
        "input_json": None,
        "description": None,
        "sensitivity": None,
        "container_input": id_value,
    })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.custom_function(custom_function="community/container_update", parameters=parameters, name="set_priority_to_high", callback=process_insight_data)

    return


@phantom.playbook_block()
def create_snow_ticket(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("create_snow_ticket() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    description_formatted_string = phantom.format(
        container=container,
        template="""Security Incident Alert - Suspicious SOC Insight Detected \n\nIncident Summary: A suspicious security insight has been identified through automated analysis of network events and requires immediate analyst review. \n\nTop 5 Critical Indicators: \n{0}\n\nTop 5 Impacted Systems:\n{1}\n\nTop 5 Related Events: \n{2}\n\nInvestigation Resources: Splunk SOAR Event with ID  : {4}\n\nInfoblox Insight Link: https://csp.infoblox.com/#/insights-console/insight/{3}\n\nNext Steps for Analyst: \n1. Review the indicators and correlate with known threat intelligence \n2. Analyze affected assets for signs of compromise \n3. Examine the event timeline for attack progression 4. Validate findings and escalate if confirmed malicious \n5. Update case with investigation findings""",
        parameters=[
            "process_insight_data:custom_function:top_5_indicators",
            "process_insight_data:custom_function:top_5_systems",
            "process_insight_data:custom_function:top_5_events",
            "artifact:*.cef.Insight ID",
            "container:id"
        ])
    short_description_formatted_string = phantom.format(
        container=container,
        template="""Infoblox -  Suspicious SOC Insight Detected -Suspicious - Suspicious""",
        parameters=[])

    ################################################################################
    # Open ticket for further investigation.
    ################################################################################

    id_value = container.get("id", None)
    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.Insight ID","artifact:*.id"])
    process_insight_data__top_5_indicators = json.loads(_ if (_ := phantom.get_run_data(key="process_insight_data:top_5_indicators")) != "" else "null")  # pylint: disable=used-before-assignment
    process_insight_data__top_5_systems = json.loads(_ if (_ := phantom.get_run_data(key="process_insight_data:top_5_systems")) != "" else "null")  # pylint: disable=used-before-assignment
    process_insight_data__top_5_events = json.loads(_ if (_ := phantom.get_run_data(key="process_insight_data:top_5_events")) != "" else "null")  # pylint: disable=used-before-assignment

    parameters = []

    # build parameters list for 'create_snow_ticket' call
    for container_artifact_item in container_artifact_data:
        parameters.append({
            "table": "incident",
            "description": description_formatted_string,
            "short_description": short_description_formatted_string,
            "context": {'artifact_id': container_artifact_item[1]},
        })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("create ticket", parameters=parameters, name="create_snow_ticket", assets=["snow"], callback=check_recommendations)

    return


@phantom.playbook_block()
def set_priority_to_low(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("set_priority_to_low() called")

    ################################################################################
    # Mark event as Informative if low risk.
    ################################################################################

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.add_tags(container=container, tags="low-priority")

    container = phantom.get_container(container.get('id', None))

    return


@phantom.playbook_block()
def fetch_insight_indicators(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("fetch_insight_indicators() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Get related security indicators for Insight.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.Insight ID","artifact:*.id"])

    parameters = []

    # build parameters list for 'fetch_insight_indicators' call
    for container_artifact_item in container_artifact_data:
        if container_artifact_item[0] is not None:
            parameters.append({
                "limit": 1000,
                "insight_id": container_artifact_item[0],
                "context": {'artifact_id': container_artifact_item[1]},
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("get iq for td insights indicators", parameters=parameters, name="fetch_insight_indicators", assets=["test_infoblox"], callback=fetch_insight_events)

    return


@phantom.playbook_block()
def process_insight_data(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("process_insight_data() called")

    ################################################################################
    # Extracts and formats the first 5 items from assets, comments, events, and indicators 
    # for incident reporting.
    ################################################################################

    fetch_insight_assets_result_data = phantom.collect2(container=container, datapath=["fetch_insight_assets:action_result.data.*.ip_address"], action_results=results)
    fetch_insight_events_result_data = phantom.collect2(container=container, datapath=["fetch_insight_events:action_result.data.*.events.*.device_ip"], action_results=results)
    fetch_insight_indicators_result_data = phantom.collect2(container=container, datapath=["fetch_insight_indicators:action_result.data.*.indicators.*.threat_indicator"], action_results=results)

    fetch_insight_assets_result_item_0 = [item[0] for item in fetch_insight_assets_result_data]
    fetch_insight_events_result_item_0 = [item[0] for item in fetch_insight_events_result_data]
    fetch_insight_indicators_result_item_0 = [item[0] for item in fetch_insight_indicators_result_data]

    process_insight_data__top_5_systems = None
    process_insight_data__top_5_indicators = None
    process_insight_data__top_5_events = None

    ################################################################################
    ## Custom Code Start
    ################################################################################
    # Process first 5 items from each result set with None checks and string conversion
    def safe_slice_join(items, limit=5, is_comments=False):
        if not items:
            return ""
        processed_items = []
        for item in items[:limit]:
            if item is None:
                continue
            item_str = str(item)
            if is_comments:
                # For comments, replace newlines with pipes
                processed_items.append(item_str.replace("\n", "|"))
            else:
                # For other items, keep newlines as they are
                processed_items.append(item_str)
        return '\n'.join(processed_items) if is_comments else ', '.join(processed_items)

    process_insight_data__top_5_systems = safe_slice_join(fetch_insight_assets_result_item_0)
    process_insight_data__top_5_events = safe_slice_join(fetch_insight_events_result_item_0)
    process_insight_data__top_5_indicators = safe_slice_join(fetch_insight_indicators_result_item_0)

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="process_insight_data__inputs:0:fetch_insight_assets:action_result.data.*.ip_address", value=json.dumps(fetch_insight_assets_result_item_0))
    phantom.save_block_result(key="process_insight_data__inputs:1:fetch_insight_events:action_result.data.*.events.*.device_ip", value=json.dumps(fetch_insight_events_result_item_0))
    phantom.save_block_result(key="process_insight_data__inputs:2:fetch_insight_indicators:action_result.data.*.indicators.*.threat_indicator", value=json.dumps(fetch_insight_indicators_result_item_0))

    phantom.save_block_result(key="process_insight_data:top_5_systems", value=json.dumps(process_insight_data__top_5_systems))
    phantom.save_block_result(key="process_insight_data:top_5_indicators", value=json.dumps(process_insight_data__top_5_indicators))
    phantom.save_block_result(key="process_insight_data:top_5_events", value=json.dumps(process_insight_data__top_5_events))

    phantom.save_block_result(key="process_insight_data_called", value="True")

    create_snow_ticket(container=container)

    return


@phantom.playbook_block()
def fetch_insight_details(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("fetch_insight_details() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.Insight ID","artifact:*.id"])

    parameters = []

    # build parameters list for 'fetch_insight_details' call
    for container_artifact_item in container_artifact_data:
        if container_artifact_item[0] is not None:
            parameters.append({
                "insight_id": container_artifact_item[0],
                "context": {'artifact_id': container_artifact_item[1]},
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("get iq for td insight details", parameters=parameters, name="fetch_insight_details", assets=["test_infoblox"], callback=update_insight_status)

    return


@phantom.playbook_block()
def update_insight_status(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("update_insight_status() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.Insight ID","artifact:*.id"])

    parameters = []

    # build parameters list for 'update_insight_status' call
    for container_artifact_item in container_artifact_data:
        if container_artifact_item[0] is not None:
            parameters.append({
                "status": "Needs Review",
                "insight_id": container_artifact_item[0],
                "context": {'artifact_id': container_artifact_item[1]},
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("update iq for td insight status", parameters=parameters, name="update_insight_status", assets=["test_infoblox"], callback=fetch_updated_insight_details)

    return


@phantom.playbook_block()
def execute_recommendation_actions(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("execute_recommendation_actions() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Execute the remediation actions recommended by the insight details.
    ################################################################################

    fetch_insight_details_result_data = phantom.collect2(container=container, datapath=["fetch_insight_details:action_result.parameter.insight_id","fetch_insight_details:action_result.data.*.key_recommendations.0.id","fetch_insight_details:action_result.parameter.context.artifact_id"], action_results=results)

    parameters = []

    # build parameters list for 'execute_recommendation_actions' call
    for fetch_insight_details_result_item in fetch_insight_details_result_data:
        if fetch_insight_details_result_item[0] is not None and fetch_insight_details_result_item[1] is not None:
            parameters.append({
                "insight_id": fetch_insight_details_result_item[0],
                "recommendation_id": fetch_insight_details_result_item[1],
                "context": {'artifact_id': fetch_insight_details_result_item[2]},
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("execute iq for td recommendation actions", parameters=parameters, name="execute_recommendation_actions", assets=["test_infoblox"], callback=check_execution_failures)

    return


@phantom.playbook_block()
def check_execution_failures(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("check_execution_failures() called")

    ################################################################################
    # Roll back if any recommendation action failed to apply.
    ################################################################################

    # check for 'if' condition 1
    found_match_1 = phantom.decision(
        container=container,
        conditions=[
            ["execute_recommendation_actions:action_result.data.*.results.*.status", "==", "failed"]
        ],
        conditions_dps=[
            ["execute_recommendation_actions:action_result.data.*.results.*.status", "==", "failed"]
        ],
        name="check_execution_failures:condition_1",
        delimiter=None)

    # call connected blocks if condition 1 matched
    if found_match_1:
        undo_recommendation_action(action=action, success=success, container=container, results=results, handle=handle)
        return

    return


@phantom.playbook_block()
def undo_recommendation_action(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("undo_recommendation_action() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Reverse the succeeded recommendation actions when part of the batch failed.
    ################################################################################

    execute_recommendation_actions_result_data = phantom.collect2(container=container, datapath=["execute_recommendation_actions:action_result.data.*.results.*.audit_entry_id","execute_recommendation_actions:action_result.parameter.context.artifact_id"], action_results=results)

    parameters = []

    # build parameters list for 'undo_recommendation_action' call
    for execute_recommendation_actions_result_item in execute_recommendation_actions_result_data:
        if execute_recommendation_actions_result_item[0] is not None:
            parameters.append({
                "audit_entry_id": execute_recommendation_actions_result_item[0],
                "context": {'artifact_id': execute_recommendation_actions_result_item[1]},
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("undo iq for td recommendation action", parameters=parameters, name="undo_recommendation_action", assets=["test_infoblox"])

    return


@phantom.playbook_block()
def fetch_updated_insight_details(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("fetch_updated_insight_details() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.Insight ID","artifact:*.id"])

    parameters = []

    # build parameters list for 'fetch_updated_insight_details' call
    for container_artifact_item in container_artifact_data:
        if container_artifact_item[0] is not None:
            parameters.append({
                "insight_id": container_artifact_item[0],
                "context": {'artifact_id': container_artifact_item[1]},
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("get iq for td insight details", parameters=parameters, name="fetch_updated_insight_details", assets=["test_infoblox"], callback=check_suspicious_events)

    return


@phantom.playbook_block()
def check_recommendations(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("check_recommendations() called")

    ################################################################################
    # Only run the recommendation actions when the insight still has recommendations 
    # that have not been actioned yet.
    ################################################################################

    # check for 'if' condition 1
    found_match_1 = phantom.decision(
        container=container,
        conditions=[
            ["fetch_insight_details:action_result.data.*.key_recommendations.*.action_taken", "==", False]
        ],
        conditions_dps=[
            ["fetch_insight_details:action_result.data.*.key_recommendations.*.action_taken", "==", False]
        ],
        name="check_recommendations:condition_1",
        delimiter=None)

    # call connected blocks if condition 1 matched
    if found_match_1:
        execute_recommendation_actions(action=action, success=success, container=container, results=results, handle=handle)
        return

    return


@phantom.playbook_block()
def on_finish(container, summary):
    phantom.debug("on_finish() called")

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    return